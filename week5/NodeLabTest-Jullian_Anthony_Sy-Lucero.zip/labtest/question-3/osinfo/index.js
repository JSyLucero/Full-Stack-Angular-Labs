const systeminfo = require('./systeminfo');
const firewall = require('./firewall');

module.exports = {
  systeminfo: systeminfo,
  firewall: firewall
}

