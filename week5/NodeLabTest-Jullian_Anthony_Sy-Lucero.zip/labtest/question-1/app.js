const calc = require('./calc');

calc.multiplyTwoNumbers(6, 6);
calc.evenDoubler(4);